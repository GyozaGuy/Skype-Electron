# Skype-Electron
An Electron Skype app designed for use on Linux systems.
