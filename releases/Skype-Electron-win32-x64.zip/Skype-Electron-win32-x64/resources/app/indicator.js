var webview = document.getElementById('webview');
webview.addEventListener('did-finish-load', function() {
  var code = "document.querySelector('div').addEventListener('change', function() { console.log('changed'); });";
  webview.executeJavaScript(code);
});
